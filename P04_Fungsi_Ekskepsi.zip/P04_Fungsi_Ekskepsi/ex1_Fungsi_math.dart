import 'dart:math';

void main(List<String> args) {
  double a;
  a = sqrt(25.0);
  print(a);
  print(pow(a, 4));
}
