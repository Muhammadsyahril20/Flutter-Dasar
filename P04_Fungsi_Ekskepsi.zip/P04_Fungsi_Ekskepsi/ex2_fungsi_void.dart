echo(dynamic value) {
  print(value.toString());
}

main(List<String> args) {
  var a = echo('Dart');
  print('Nilai a: $a');
}
