void main (List<String>args){
print ('pemrograman Android');
print ('Menggunakan Dart dan Flutter');
int a,b,c;
String strA = "A";
double d; int i;

}