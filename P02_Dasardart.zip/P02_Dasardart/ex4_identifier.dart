//pengenal (identifier)
void main(List<String> args) {
    String namaDepan;
    double dimensi2;
    var tanda = '#';
}
