// deklarasi variabel
void main(List<String> args) {
    double panjang = 10.4;
    double lebar = 8.5;

    double luas = panjang * lebar;
    double keliling = 2 * (panjang + lebar);

    print('Luas persegi panjang\t\t: ${luas}');
    print('Keliling persegi panjang\t: ${keliling}');
}
