import 'dart:io';

void main(List<String> args) {
  int? a; // Gunakan tipe nullable untuk menangani input kosong
  stdout.write('Masukkan nilai a [0..9]: ');

  try {
    String? input = stdin.readLineSync();
    if (input == null || input.isEmpty) {
      throw FormatException('Input tidak boleh kosong');
    }

    a = int.parse(input);

    if (a >= 0 && a <= 9) {
      print('Anda memasukkan nilai: $a');
    } else {
      print('Nilai yang dimasukkan harus 0..9');
    }
  } catch (e) {
    print('Input tidak valid! Masukkan angka antara 0 hingga 9.');
  }
}
