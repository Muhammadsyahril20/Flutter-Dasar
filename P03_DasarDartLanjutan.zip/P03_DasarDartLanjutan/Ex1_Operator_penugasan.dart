//operator penugasan
void main(List<String> args) {
  int a;
  a = 3;
  print('a = $a');

  a += 2;
  print('a = $a');

  a -= 1;
  print('a = $a');

  a *= 2;
  print('a = $a');

  a ~/= 3;
  print('a = $a');

  double b = 7;
  b /= a;
  print('b = $b');
}
