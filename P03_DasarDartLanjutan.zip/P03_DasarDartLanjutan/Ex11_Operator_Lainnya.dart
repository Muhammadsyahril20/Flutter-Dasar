// Operator lainnya
void main(List<String> args) {
  print(2 is int);      // Mengecek apakah 2 adalah integer
  print(2 is num);      // Mengecek apakah 2 adalah angka (num)
  print(2 is! String);  // Mengecek apakah 2 bukan String
  print([1, 2, 3] is Map); // Mengecek apakah list ini bertipe Map (false)

  num a = 9, b = 10;

  // Pastikan 'a' bertipe int sebelum menggunakan properti 'isOdd' dan 'isEven'
  if (a is int) {
    print(a.isOdd);  // Mengecek apakah 'a' bilangan ganjil
    print(a.isEven); // Mengecek apakah 'a' bilangan genap
  }

  // Operator ternary untuk mencari nilai maksimum
  int maks = (a > b) ? a.toInt() : b.toInt();
  print('Nilai max dari $a dan $b adalah $maks');

  // Menggunakan null safety untuk menangani 'a' yang bisa null
  int c = (a as int?) ?? b.toInt();
  print('Nilai c: $c');
}
