//operator aritmatika
void main(List<String> args) {
  int a = 10, b = 3;
  double c = 10.0;

  print('\n$a + $b = ${a + b}');
  print('$a - $b = ${a - b}');
  print('$a * $b = ${a * b}');
  print('$a / $b = ${a / b}');
  print('$a ~/ $b = ${a ~/ b}');
  print('$a % $b = ${a % b}');
}
