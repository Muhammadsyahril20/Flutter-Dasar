//operator relasional
void main(List<String> args) {
  int a = 9, b = 10;

  print('$a == $b: ${a == b}');
  print('$a != $b: ${a != b}');
  print('$a > $b: ${a > b}');
  print('$a >= $b: ${a >= b}');
  print('$a < $b: ${a < b}');
  print('$a <= $b: ${a <= b}');
}
