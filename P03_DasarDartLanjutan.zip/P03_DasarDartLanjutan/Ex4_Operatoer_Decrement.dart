//operator decrement (pengurangan nilai dengan 1)
void main(List<String> args) {
  int a = 9, b = a;

  print('Pre-decrement');
  print('Nilai a awal: $a');
  print('--a: ${--a}');
  print('Nilai a akhir: $a');

  print('\nPost-decrement');
  print('Nilai b awal: $b');
  print('b--: ${b--}');
  print('Nilai b akhir: $b');
}
