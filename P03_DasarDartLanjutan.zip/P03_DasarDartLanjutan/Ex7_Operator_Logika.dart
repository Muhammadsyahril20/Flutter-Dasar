//operator logika
void main(List<String> args) {
  print('Logika AND');
  print('true && true\t: ${true && true}');
  print('true && false\t: ${true && false}');
  print('false && false\t: ${false && false}');
  print('false && true\t: ${false && true}');

  print('\nLogika OR');

  print('true || true\t: ${true || true}');
  print('true || false\t: ${true || false}');
  print('false || false\t: ${false || false}');
  print('false || true\t: ${false || true}');

  print('\nLogika NOT');
  print('!true\t: ${!true}');
  print('!false\t: ${!false}');
}
