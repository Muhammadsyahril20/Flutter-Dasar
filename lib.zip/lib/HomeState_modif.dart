//width & Hight
// class _HomeState extends State<Home> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Percobaan Menggunakan Widget'),
//       ),
//       body: Container(
//         child: const Text(
//           'RPL Polbeng',
//           style: TextStyle(
//             fontSize: 40,
//             color: Colors.white,
//           ),
//         ),
//         color: Colors.blue,
//         width: 250,
//         height: 100,
//       ),
//     );
//   }
// }


//Pedding 
// class _HomeState extends State<Home> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Percobaan Menggunakan Widget'),
//       ),
//       body: Container(
//         child: const Text(
//           'RPL Polbeng',
//           style: TextStyle(
//             fontSize: 40,
//             color: Colors.white,
//           ),
//         ),
//         color: Colors.blue,
//         width: 250,
//         height: 100,
//         padding: const EdgeInsets.all(10),
//         margin: const EdgeInsets.all(10),
//       ),
//     );
//   }
// }



